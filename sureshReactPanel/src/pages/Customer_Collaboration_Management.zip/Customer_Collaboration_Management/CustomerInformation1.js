// @mui
import * as React from 'react';
import { useState } from 'react';
import { useForm, Controller } from "react-hook-form";
import AddIcon from '@mui/icons-material/Add';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import DoneIcon from '@mui/icons-material/Done';
import {
  Grid,
  Card,
  CardHeader,
  TextField,
  Button,
  MenuItem,
  FormControl,
  InputLabel,
  Box,
  Select,
} from '@mui/material';
import FormHelperText from "@mui/material/FormHelperText";
// components
import Page from '../../components/Page';
// sections
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';

// ----------------------------------------------------------------------
const defaultValues = {
  select: '',
  servicesidecustomerID: '',
  federatedCustomerID: '',
  mr:'',
  dob:'',
  firstname:'',
  email:'',
  paymentagencyID:''
}

const showErrors = (field, valueLen, min) => {
	if (valueLen === 0) {
		return `${field} field is required`;
	} else if (valueLen > 0 && valueLen < min) {
		return `${field} must be at least ${min} characters`;
	} else {
		return "";
	}
};

const Customer = () => {


  // Add Fields
  const [inputFields, setInputFields] = useState([
    { name: '', id: '' }
  ])

  const [disabled, setDisabled] = useState(false);

  const [value, setValue] = React.useState(null);

  const handleFormChange = (index, event) => {
    let data = [...inputFields];
    data[index][event.target.name] = event.target.value;
    setInputFields(data);
  }
  const addFields = () => {
    let newfield = { name: '', id: '' }
    setInputFields([...inputFields, newfield])
  }
  const removeFields = (index) => {
    let data = [...inputFields];
    data.splice(index, 1)
    setInputFields(data)
  }


  const [customer, setCustomer] = useState({
    enabledisable: '',
    servicesidecustomerID: '',
    mr: '',
    emailaddress: '',
    servicesidecustomerID: '',
    accesstime: '',
    customerinformationexpirationdate: '',
    linkedcustomerID: '',
    Registrationdate: '',
    nextpaymentdate: '',
    paymentagencyID: '',
    Lastupdatetime: '',
    Attributes: { ...inputFields },
  });

  const {
    control,
    handleSubmit,
    formState: { errors }
  } = useForm({ defaultValues })


  const handleChange = (e) => {
    // console.log(e);
    const name = '';
    const value = '';
    name = e.target.name;
    value = e.target.value;
    setCustomer({ ...customer, [name]: value });
  };

  const handleDisable = (e) =>
  {
    setDisabled(true);
  }

  const handleEnDisable = () =>
  {
    setDisabled(false);
  }

  const onSubmit = (e) => {
    console.log("Customer Form Fields", e)
    console.log("Customer Input Fields", inputFields)

  };


  return (
    <Page className="User Overview" title="顧客一覧 / 顧客情報​">
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Card className="RoleCard">
            <CardHeader title="顧客情報​" className="RolePageHeading" />
            <form onSubmit={handleSubmit(onSubmit)}>
            <Grid container spacing={2} className="RoleCardBody">
              <Grid item xs={6}>
            <Box className="BoxWidth">
              <FormControl fullWidth>
                <InputLabel
                  id='validation-basic-select'
                  error={Boolean(errors.select)}
                  htmlFor='validation-basic-select'
                >
                  お客様
                </InputLabel>
                <Controller
                  name='select'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <Select
                      value={value}
                      label='Country'
                      onChange={onChange}
                      error={Boolean(errors.select)}
                      labelId='validation-basic-select'
                      aria-describedby='validation-basic-select'
                    >
                      <MenuItem value='有効' onClick={handleEnDisable}>有効</MenuItem>
                      <MenuItem value='無効' onClick={handleDisable}>無効</MenuItem>
                    </Select>
                  )}
                />
                {errors.select && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-select'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
            </Box>

              <Box className="BoxWidth">
              <FormControl fullWidth>
                <Controller
                  name='servicesidecustomerID'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <TextField
                      value={value}
                      label='サービス側の顧客 ID'
                      onChange={onChange}
                      placeholder='サービス側の顧客 ID'
                      error={Boolean(errors.servicesidecustomerID)}
                      aria-describedby='validation-basic-servicesidecustomerID'
                    />
                  )}
                />
                {errors.servicesidecustomerID && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-servicesidecustomerID'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>

                <Box className="BoxWidth">
              <FormControl fullWidth>
                <Controller
                  name='mr'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <TextField
                      value={value}
                      label='氏​'
                      onChange={onChange}
                      placeholder='氏​'
                      error={Boolean(errors.mr)}
                      aria-describedby='validation-basic-mr'
                    />
                  )}
                />
                {errors.mr && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-mr'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>

                <Box className="BoxWidth">
              <FormControl fullWidth>
                <Controller
                  name='firstname'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <TextField
                      value={value}
                      label='名​​'
                      onChange={onChange}
                      placeholder='名​​'
                      error={Boolean(errors.firstname)}
                      aria-describedby='validation-basic-firstname'
                    />
                  )}
                />
                {errors.firstname && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-firstname'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>  


                <Box className="BoxWidth">
                <FormControl fullWidth>
                <Controller
                  name='email'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <TextField
                      type='email'
                      value={value}
                      label='Eメール'
                      onChange={onChange}
                      error={Boolean(errors.email)}
                      placeholder='管理者@dti.com'
                      aria-describedby='validation-basic-email'
                    />
                  )}
                />
                {errors.email && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-email'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>    

              <Box className="BoxWidth">
                <FormControl fullWidth>
                <InputLabel
                  id='validation-basic-select'
                  error={Boolean(errors.select)}
                  htmlFor='validation-basic-select'
                >
                  最終アクセス日時​
                </InputLabel>
                <Controller
                  name='lastaccesstime'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <Select
                      value={value}
                      label='最終アクセス日時​'
                      onChange={onChange}
                      disabled={disabled}
                      error={Boolean(errors.select)}
                      labelId='validation-basic-select'
                      aria-describedby='validation-basic-select'
                    >
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                    </Select>
                  )}
                />
                {errors.select && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-select'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>

            <Box className="BoxWidth">
               <FormControl fullWidth>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                label="Basic example"
                value={value}
                onChange={(newValue) => {
                setValue(newValue);
                }}
                renderInput={(params) => <TextField {...params} />}
               />
              </LocalizationProvider>
                </FormControl>
            </Box>

              </Grid>

              <Grid item xs={6}>

                <Box className="BoxWidth">
                <FormControl fullWidth>
                <InputLabel
                  id='validation-basic-select'
                  error={Boolean(errors.select)}
                  htmlFor='validation-basic-select'
                >
                  顧客情報有効期限​
                </InputLabel>
                <Controller
                  name='customerinformationexpirationdate'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <Select
                      value={value}
                      label='顧客情報有効期限​'
                      onChange={onChange}
                      error={Boolean(errors.select)}
                      labelId='validation-basic-select'
                      aria-describedby='validation-basic-select'
                    >
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                    </Select>
                  )}
                />
                {errors.select && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-select'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>
  

                <Box className="BoxWidth">
              <FormControl fullWidth>
                <Controller
                  name='federatedCustomerID'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <TextField
                      value={value}
                      label='フェデレーション カスタマー ID'
                      onChange={onChange}
                      disabled={disabled}
                      placeholder='フェデレーション カスタマー ID'
                      error={Boolean(errors.servicesidecustomerID)}
                      aria-describedby='validation-basic-federatedCustomerID'
                    />
                  )}
                />
                {errors.federatedCustomerID && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-federatedCustomerID'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
              </Box>

                <Box className="BoxWidth">
                <FormControl fullWidth>
                <InputLabel
                  id='validation-basic-select'
                  error={Boolean(errors.select)}
                  htmlFor='validation-basic-select'
                >
                  登録日時​
                </InputLabel>
                <Controller
                  name='registrationdate'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <Select
                      value={value}
                      label='登録日時​'
                      onChange={onChange}
                      disabled={disabled}
                      error={Boolean(errors.select)}
                      labelId='validation-basic-select'
                      aria-describedby='validation-basic-select'
                    >
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                    </Select>
                  )}
                />
                {errors.select && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-select'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>
  

                <Box className="BoxWidth">
                <FormControl fullWidth>
                <InputLabel
                  id='validation-basic-select'
                  error={Boolean(errors.select)}
                  htmlFor='validation-basic-select'
                >
                  次回決済予定日​
                </InputLabel>
                <Controller
                  name='nextpaymentdate'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <Select
                      value={value}
                      label='次回決済予定日​'
                      onChange={onChange}
                      disabled={disabled}
                      error={Boolean(errors.select)}
                      labelId='validation-basic-select'
                      aria-describedby='validation-basic-select'
                    >
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                    </Select>
                  )}
                />
                {errors.select && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-select'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>

                <Box className="BoxWidth">
              <FormControl fullWidth>
                <Controller
                  name='paymentagencyID'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <TextField
                      value={value}
                      label='決済代行会社ID'
                      disabled={disabled}
                      onChange={onChange}
                      placeholder='決済代行会社ID'
                      error={Boolean(errors.paymentagencyID)}
                      aria-describedby='validation-basic-paymentagencyID'
                    />
                  )}
                />
                {errors.paymentagencyID && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-paymentagencyID'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
              </Box>  

              <Box className="BoxWidth">
                <FormControl fullWidth>
                <InputLabel
                  id='validation-basic-select'
                  error={Boolean(errors.select)}
                  htmlFor='validation-basic-select'
                >
                  次回決済予定日​
                </InputLabel>
                <Controller
                  name='Lastupdatetime'
                  control={control}
                  rules={{ required: true }}
                  render={({ field: { value, onChange } }) => (
                    <Select
                      value={value}
                      label='最終更新日時​'
                      onChange={onChange}
                      disabled={disabled}
                      error={Boolean(errors.select)}
                      labelId='validation-basic-select'
                      aria-describedby='validation-basic-select'
                    >
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                      <MenuItem value={'2022-09-01 00:00'}>2022-09-01 00:00</MenuItem>
                    </Select>
                  )}
                />
                {errors.select && (
                  <FormHelperText sx={{ color: 'error.main' }} id='validation-basic-select'>
                    This field is required
                  </FormHelperText>
                )}
              </FormControl>
                </Box>

              </Grid>
              <Grid container direction="column" xs={12} className="AddGridPadding">
                <p className='AddGridHeading'>メタデータ</p>
                <Grid className='AddGrid'>
                  {inputFields.map((input, index) => {
                    return (
                      <>
                        <div key={index} className='AddInputDiv'>
                          <Grid item xs={5.5}>
                            <input
                              name='name'
                              placeholder='メルマガ​'
                              value={input.name}
                              onChange={event => handleFormChange(index, event)}
                            />
                          </Grid>
                          <Grid item xs={5.5}>
                            <input
                              name='id'
                              placeholder='XXXXXXXXXXXXX'
                              value={input.id}
                              onChange={event => handleFormChange(index, event)}
                            />
                          </Grid>
                          <IconButton onClick={() => removeFields(index)} aria-label="delete" size="small" className='RomoveButton'>
                            <CloseIcon fontSize="inherit" />
                          </IconButton>
                        </div>
                      </>
                    )
                  })}
                  <div className='bottom-button'>
                    <Button onClick={addFields} variant="contained" className="SaveButton" startIcon={<AddIcon />}>
                      メタデータ追加
                    </Button>
                    <Button variant="contained" className="SaveButton" startIcon={<DoneIcon />} type="submit">
                      保存
                    </Button>
                  </div>
                </Grid>
              </Grid>
            </Grid>
            </form>
          </Card>
        </Grid>
      </Grid>
    </Page>
  );
};
export default Customer;
