// @mui
import * as React from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';

import DoneIcon from '@mui/icons-material/Done';

import {
  Grid,
  Card,
  CardHeader,
  TextField,
  Button,
  MenuItem,
  FormControl,
  InputLabel,
  Box,
  Select,
  TableContainer,
  Table,
  TableBody,
  TableRow,
  TableCell,

} from '@mui/material';

// components
import Page from '../../components/Page';
import Scrollbar from '../../components/Scrollbar';
import { UserListHead, UserMoreMenu } from '../../sections/@dashboard/user';
// mock
import USERLIST from '../../_mock/user';


// sections

// ----------------------------------------------------------------------
const TABLE_HEAD = [
  { id: '購入日付', label: '購入日付', alignRight: false },
  { id: '契約番号', label: '契約番号', alignRight: false },
  { id: '契約形態', label: '契約形態', alignRight: false },
  { id: '購入商品', label: '購入商品', alignRight: false },
  { id: '契約開始日', label: '契約開始日', alignRight: false },
  { id: '契約終了日', label: '契約終了日', alignRight: false },
  { id: '決済種別', label: '決済種別', alignRight: false },
  { id: '決済日時', label: '決済日時', alignRight: false },
  { id: '展開', label: '展開', alignRight: false },
];
function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(array, (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}
const Customer = () => {
  const [page, setPage] = useState(0);

  const [order, setOrder] = useState('asc');

  const [orderBy, setOrderBy] = useState('購入日付');

  const [filterName, setFilterName] = useState('');

  const [rowsPerPage, setRowsPerPage] = useState(2);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - USERLIST.length) : 0;

  const filteredUsers = applySortFilter(USERLIST, getComparator(order, orderBy), filterName);

  const isUserNotFound = filteredUsers.length === 0;


  const [customer, setCustomer] = useState({
    enabledisable: '',
    billingemailaddress: '',
    billingname: '',
    postalcode: '',
    address: '',
    address2: '',
  });
  let name = '';
  let value = '';

  const handleChange = (e) => {
    // console.log(e);
    name = e.target.name;
    value = e.target.value;
    setCustomer({ ...customer, [name]: value });
  };
  const onSubmit = (e) => {
    console.log("Customer Form Fields", customer)
  };

  return (
    <Page className="User Overview" title="顧客一覧 ／ 顧客情報​">
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Card className="RoleCard">
            <CardHeader title="顧客情報（１／２）からの続き" className="RolePageHeading" />
            <Grid container spacing={2} className="RoleCardBody align-flex-end">
              <Grid item xs={6}>

                <Box className="BoxWidth">
                  <FormControl fullWidth>
                    <InputLabel id="enabledisable-label">請求先情報有無​</InputLabel>
                    <Select
                      labelId="enabledisable-label"
                      id="enabledisable"
                      value={customer.enabledisable}
                      label="顧客有効／無効​"
                      name="enabledisable"
                      onChange={handleChange}
                    >
                      <MenuItem value={'有り'}>有り​</MenuItem>
                      <MenuItem value={'有り2'}>有り2</MenuItem>
                    </Select>
                  </FormControl>
                </Box>

                <Box className="BoxWidth">
                  <FormControl fullWidth>
                    <TextField label="請求先メールアドレス"
                      name="billingemailaddress"
                      value={customer.billingemailaddress}
                      onChange={handleChange}
                    />
                  </FormControl>
                </Box>

                <Box className="BoxWidth">
                  <FormControl fullWidth>
                    <TextField label="請求先名​"
                      name="billingname"
                      value={customer.billingname}
                      onChange={handleChange}
                    />
                  </FormControl>
                </Box>

                <Box className="BoxWidth">
                  <FormControl fullWidth>
                    <TextField label="郵便番号​"
                      name="postalcode"
                      value={customer.postalcode}
                      onChange={handleChange}
                    />
                  </FormControl>
                </Box>

              </Grid>

              <Grid item xs={6}>

                <Box className="BoxWidth">
                  <FormControl fullWidth>
                    <TextField label="住所​"
                      name="address"
                      value={customer.address}
                      onChange={handleChange}
                    />
                  </FormControl>
                </Box>

                <Box className="BoxWidth">
                  <FormControl fullWidth>
                    <TextField label="住所２​"
                      name="address2"
                      value={customer.address2}
                      onChange={handleChange}
                    />
                  </FormControl>
                </Box>

                <Box className="BoxWidth">
                  <FormControl fullWidth>
                    <TextField label="電話番号​"
                      name="phonenumber"
                      value={customer.phonenumber}
                      onChange={handleChange}
                    />
                  </FormControl>
                </Box>

              </Grid>

            </Grid>
            <Grid container justifyContent="space-between" alignItems="center" xs={12} className="RoleCardButton">
              <Button variant="outlined" className="DeleteButton">
                削除
              </Button>
              <Button variant="contained" className="SaveButton" startIcon={<DoneIcon />} onClick={onSubmit}>
                保存
              </Button>
            </Grid>
          </Card>

          <Card className='Customer-list-filter'>
            <div className='customer-imformation-div'>
              <h1>最近の決済履歴​</h1>
            </div>
            <Scrollbar>
              <TableContainer>
                <Table>
                  <UserListHead
                    order={order}
                    orderBy={orderBy}
                    headLabel={TABLE_HEAD}
                    onRequestSort={handleRequestSort}
                  />
                  <TableBody>
                    {filteredUsers.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                      const { id, name, role, status, company, avatarUrl, isVerified } = row;

                      return (
                        <TableRow hover key={id} className="table-body">
                          <TableCell align="left">2022-09-01</TableCell>
                          <TableCell align="left">
                            <Link to="/customer-information-1" className="table-link">
                              000004{' '}
                            </Link>
                          </TableCell>
                          <TableCell align="left"> 一括決済</TableCell>
                          <TableCell align="left"> 商品A</TableCell>
                          <TableCell align="left">2022-09-01</TableCell>
                          <TableCell align="left">2022-09-01</TableCell>
                          <TableCell align="left">クレジット</TableCell>
                          <TableCell align="left">2022-09-01</TableCell>

                          <TableCell align="right">
                            <UserMoreMenu />
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>

                </Table>
              </TableContainer>
            </Scrollbar>
            <div className="customer-imformation-div">
              全て表示
            </div>
          </Card>

        </Grid>
      </Grid>
    </Page>
  );
};
export default Customer;
