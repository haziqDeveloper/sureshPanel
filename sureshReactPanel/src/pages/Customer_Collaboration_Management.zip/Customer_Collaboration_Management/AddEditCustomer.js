/** @format */

// @mui
import * as yup from "yup";
import * as React from "react";
import { useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup/dist/yup";
import { Dayjs } from "dayjs";
import moment from "moment";
import DoneIcon from "@mui/icons-material/Done";
import {
	Grid,
	Card,
	CardHeader,
	Button,
	MenuItem,
	FormControl,
	InputLabel,
	Box,
	Select,
} from "@mui/material";
import TextField from "@mui/material/TextField";
import FormHelperText from "@mui/material/FormHelperText";
import { editCustomerAPI } from "../../store/api";
import {
	postCustomer,
	updateCustomer,
} from "src/store/services/customerService";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import toast, { Toaster } from "react-hot-toast";
// components
import Page from "../../components/Page";
import { DatePicker } from "@mui/x-date-pickers";
import { useEffect } from "react";
import Instance from "src/store/axois";
// sections

// ----------------------------------------------------------------------

const defaultValues = {
	email: "",
	mailAddress: "",
	billingMailAddress: "",
	familyName: "",
	givenName: "",
	mailAddress: "",
	billingName: "",
	billingZip: "",
	billingAddress: "",
	billingAddress2: "",
	billingPhone: "",
};

const showErrors = (field, valueLen, min) => {
	if (valueLen === 0) {
		return `${field} field is required`;
	} else if (valueLen > 0 && valueLen < min) {
		return `${field} must be at least ${min} characters`;
	} else {
		return "";
	}
};

const schema = yup.object().shape({
	email: yup.string().email().required(),
	familyName: yup
		.string()
		.min(3, (obj) => showErrors("Family Name", obj.value.length, obj.min))
		.required(),
	givenName: yup
		.string()
		.min(3, (obj) => showErrors("Given Name", obj.value.length, obj.min))
		.required(),
	billingMailAddress: yup
		.string()
		.min(3, (obj) =>
			showErrors("Billing Mail Address", obj.value.length, obj.min),
		)
		.required(),
	mailAddress: yup
		.string()
		.min(3, (obj) => showErrors("Mail Address", obj.value.length, obj.min))
		.required(),
	billingName: yup
		.string()
		.min(3, (obj) => showErrors("Billing Name", obj.value.length, obj.min))
		.required(),
	billingZip: yup
		.string()
		.min(3, (obj) => showErrors("Billing Zip", obj.value.length, obj.min))
		.required(),
	billingAddress: yup
		.string()
		.min(3, (obj) => showErrors("Billing Address", obj.value.length, obj.min))
		.required(),
	billingAddress2: yup
		.string()
		.min(3, (obj) => showErrors("Billing Address 2", obj.value.length, obj.min))
		.required(),
	billingPhone: yup
		.string()
		.min(3, (obj) => showErrors("Billing Phone", obj.value.length, obj.min))
		.required(),
});

const AddCustomer = (props) => {
	const navigate = useNavigate();
	const [dateValue, setDateValue] = useState(new Date());

	const [user, setUser] = useState({
		serviceId: "1",
		familyName: "",
		givenName: "",
		mailAddress: "",
		email: "",
		validStartDate: "",
		billingMailAddress: "",
		billingName: "",
		billingZip: "",
		billingAddress: "",
		billingAddress2: "",
		billingPhone: "",
	});

	const {
		control,
		handleSubmit,
		setValue,
		formState: { errors },
	} = useForm({
		defaultValues,
		mode: "onChange",
		resolver: yupResolver(schema),
	});

	const { id } = useParams();
	const location = useLocation();

	const API_URL = process.env.REACT_APP_API_LOCAL;

	const onSubmit = async (params) => {
		const xyz = params;
		xyz.serviceId = "1";
		if (location.pathname == "/add-customer") {
			postCustomer(xyz).then((r) => {
				if (r.status == 201) {
					toast.success("顧客を追加しました");
					setTimeout(() => {
						navigate("/customer-list");
					}, 1000);
				}
			});
		} else {
			xyz.id = id;
			updateCustomer(xyz).then((r) => {
				if (r.status == 200) {
					toast.success("顧客の更新に成功しました");
					setTimeout(() => {
						navigate("/customer-list");
					}, 1000);
				}
			});
		}
	};

	useEffect(() => {
		console.log("params", props);
		editCustomer();
	}, []);

	const editCustomer = async () => {
		const response = await Instance.get(API_URL + editCustomerAPI, {
			params: { custId: id },
		});
		console.log("editResponse", response);
		const data = response.data;
		setUser(data);
		Object.keys(data).map((key) => {
			setValue(key, data[key]);
		});
	};

	const backPage = () => {
		navigate("/customer-list");
	};

	return (
		<Page className="User Overview" title="運用者一覧／ 運用者">
			<Grid container spacing={2}>
				<Grid item xs={12}>
					<Card className="RoleCard">
						<CardHeader title="運用者" className="RolePageHeading" />
						<form onSubmit={handleSubmit(onSubmit)}>
							<Grid container spacing={2} className="RoleCardBody">
								<Grid item xs={6}>
									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="familyName"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="苗字*"
														placeholder="苗字*"
														error={Boolean(errors.familyName)}
														aria-describedby="validation-schema-familyName"
													/>
												)}
											/>
											{errors.familyName && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-familyName">
													{errors.familyName.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>

									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="givenName"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="名*"
														placeholder="苗字*"
														error={Boolean(errors.givenName)}
														aria-describedby="validation-schema-givenName"
													/>
												)}
											/>
											{errors.givenName && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-givenName">
													{errors.givenName.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>

									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="mailAddress"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="メールアドレス"
														placeholder="メールアドレス"
														error={Boolean(errors.mailAddress)}
														aria-describedby="validation-schema-mailAddress"
													/>
												)}
											/>
											{errors.mailAddress && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-mailAddress">
													{errors.mailAddress.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>

									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="email"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="Eメール"
														placeholder="Eメール"
														error={Boolean(errors.email)}
														aria-describedby="validation-schema-email"
													/>
												)}
											/>
											{errors.email && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-email">
													{errors.email.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>

									<Box className="BoxWidth">
										<LocalizationProvider
											dateAdapter={AdapterDateFns}
											className="DateFullWidth">
											<DatePicker
												label="有効期間"
												value={dateValue}
												onChange={(newValue) => {
													setDateValue(newValue);
													setUser({ ...user, ["validStartDate"]: newValue });
													setValue("validStartDate", newValue);
												}}
												renderInput={(params) => <TextField {...params} />}
											/>
										</LocalizationProvider>
									</Box>

									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="billingMailAddress"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														name="billingMailAddress"
														value={value}
														onChange={onChange}
														label="請求メールアドレス"
														placeholder="請求メールアドレス"
														error={Boolean(errors.billingMailAddress)}
														aria-describedby="validation-schema-billingMailAddress"
													/>
												)}
											/>
											{errors.billingMailAddress && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-billingMailAddress">
													{errors.billingMailAddress.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>
								</Grid>

								<Grid item xs={6}>
									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="billingName"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="課金名"
														placeholder="課金名"
														error={Boolean(errors.billingName)}
														aria-describedby="validation-schema-billingName"
													/>
												)}
											/>
											{errors.billingName && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-billingName">
													{errors.billingName.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>

									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="billingZip"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="請求先の郵便番号"
														placeholder="請求先の郵便番号"
														error={Boolean(errors.billingZip)}
														aria-describedby="validation-schema-billingZip"
													/>
												)}
											/>
											{errors.billingZip && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-billingZip">
													{errors.billingZip.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>

									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="billingAddress"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="請求先住所"
														placeholder="請求先住所"
														error={Boolean(errors.email)}
														aria-describedby="validation-schema-billingAddress"
													/>
												)}
											/>
											{errors.billingAddress && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-billingAddress">
													{errors.billingAddress.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>

									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="billingAddress2"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="請求先住所2"
														placeholder="請求先住所2"
														error={Boolean(errors.email)}
														aria-describedby="validation-schema-billingAddress2"
													/>
												)}
											/>
											{errors.billingAddress2 && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-billingAddress2">
													{errors.billingAddress2.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>

									<Box className="BoxWidth">
										<FormControl fullWidth>
											<Controller
												name="billingPhone"
												control={control}
												rules={{ required: true }}
												render={({ field: { value, onChange } }) => (
													<TextField
														value={value}
														onChange={onChange}
														label="課金電話"
														placeholder="課金電話"
														error={Boolean(errors.email)}
														aria-describedby="validation-schema-billingPhone"
													/>
												)}
											/>
											{errors.billingPhone && (
												<FormHelperText
													sx={{ color: "error.main" }}
													id="validation-schema-billingPhone">
													{errors.billingPhone.message}
												</FormHelperText>
											)}
										</FormControl>
									</Box>
								</Grid>
							</Grid>
							<Grid
								container
								justifyContent="space-between"
								alignItems="center"
								xs={12}
								className="RoleCardButton mt-30">
								<Button
									variant="outlined"
									className="DeleteButton"
									onClick={backPage}>
									削除
								</Button>
								<Button
									variant="contained"
									className="SaveButton"
									startIcon={<DoneIcon />}
									type="submit">
									保存
								</Button>
							</Grid>
						</form>
					</Card>
				</Grid>
			</Grid>
		</Page>
	);
};
export default AddCustomer;
